local function import(url)
    return loadstring(game:HttpGet(url))()
end

local base = "https://raw.githubusercontent.com/usuario/Ryuma-Hub/main/modules/"
local UI = import(base .. "init.lua")
local Features = import(base .. "features.lua")
local ESP = import(base .. "esp.lua")

UI.TabMain:CreateToggle({ Name = "Inf Breath", CurrentValue = false, Callback = Features.toggleInfBreath })
UI.TabMain:CreateToggle({ Name = "Inf Stam", CurrentValue = false, Callback = Features.toggleInfStam })
UI.TabMain:CreateToggle({ Name = "Inf Battery", CurrentValue = false, Callback = Features.toggleInfBattery })

UI.TabLocalPlayer:CreateToggle({ Name = "ESP Mutant", CurrentValue = false, Callback = ESP.toggleESP })
UI.TabLocalPlayer:CreateToggle({ Name = "FullBright", CurrentValue = false, Callback = Features.toggleFullBright })
UI.TabLocalPlayer:CreateButton({ Name = "Disable Temperature", Callback = Features.disableTemperature })
UI.TabLocalPlayer:CreateButton({ Name = "Camera Mode Classic", Callback = Features.cameraClassic })

UI.Rayfield:LoadConfiguration()
