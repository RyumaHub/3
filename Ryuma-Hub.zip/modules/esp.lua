local Camera = workspace.CurrentCamera
local quad = Drawing.new("Quad")
local text = Drawing.new("Text")
quad.Visible = false
quad.Color = Color3.fromRGB(255,0,0)
quad.Thickness = 2
quad.Transparency = 1
text.Visible = false
text.Center = true
text.Size = 18
text.Color = Color3.fromRGB(255,0,0)
text.Outline = true
text.Font = 2

getgenv().espLoop = false

game:GetService("RunService").RenderStepped:Connect(function()
    if not getgenv().espLoop then
        quad.Visible = false
        text.Visible = false
        return
    end
    local mutant = workspace:FindFirstChild("Mutant")
    local hrp = game.Players.LocalPlayer.Character and game.Players.LocalPlayer.Character:FindFirstChild("HumanoidRootPart")
    if mutant and mutant:FindFirstChild("HumanoidRootPart") and hrp then
        local part = mutant.HumanoidRootPart
        local cf = part.CFrame
        local size = mutant:GetExtentsSize()
        size = Vector3.new(size.X,size.Y,0)

        local function w2vp(pos)
            local p = Camera:WorldToViewportPoint(pos)
            return Vector2.new(p.X,p.Y), p.Z > 0
        end

        local tl, ok1 = w2vp(cf * CFrame.new(-size.X/2,size.Y/2,0).Position)
        local tr, ok2 = w2vp(cf * CFrame.new(size.X/2,size.Y/2,0).Position)
        local br, ok3 = w2vp(cf * CFrame.new(size.X/2,-size.Y/2,0).Position)
        local bl, ok4 = w2vp(cf * CFrame.new(-size.X/2,-size.Y/2,0).Position)

        if ok1 and ok2 and ok3 and ok4 then
            quad.PointA, quad.PointB = tl, tr
            quad.PointC, quad.PointD = br, bl
            quad.Visible = true
            local dist = math.floor((hrp.Position - part.Position).Magnitude)
            text.Text = "MUTANT ["..dist.."m]"
            text.Position = Vector2.new((tl.X+br.X)/2, tl.Y - 20)
            text.Visible = true
        else
            quad.Visible = false
            text.Visible = false
        end
    else
        quad.Visible = false
        text.Visible = false
    end
end)

return {
    toggleESP = function(state)
        getgenv().espLoop = state
    end
}
