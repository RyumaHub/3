local Rayfield = loadstring(game:HttpGet("https://sirius.menu/rayfield"))()
local Window = Rayfield:CreateWindow({
    Name = "RESIDENCE MASSACRE RYUMA HUB",
    Icon = "file",
    LoadingTitle = "RYUMA",
    LoadingSubtitle = "By RYUMA",
    Theme = "DarkBlue",
    DisableRayfieldPrompts = true,
    DisableBuildWarnings = true,
    ConfigurationSaving = { Enabled = true, FolderName = nil, FileName = "RMN1" }
})

local TabMain = Window:CreateTab("Main", "rewind")
local TabLocalPlayer = Window:CreateTab("LocalPlayer", "user")

return { Rayfield = Rayfield, Window = Window, TabMain = TabMain, TabLocalPlayer = TabLocalPlayer }
