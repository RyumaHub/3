local Player = game.Players.LocalPlayer
local char = Player.Character or Player.CharacterAdded:Wait()
local sprint = char:WaitForChild("Sprint")
local stam = sprint:WaitForChild("Stam")
local breath = char:WaitForChild("Breath")
local overdrive = sprint:WaitForChild("Overdrive")

getgenv().original = {
    stamMax = stam:GetAttribute("Max"),
    stamVal = stam.Value,
    breathMax = breath:GetAttribute("Max"),
    breathVal = breath.Value,
    overdriveVal = overdrive.Value
}

return {
    toggleInfBreath = function(state)
        breath:SetAttribute("Max", state and math.huge or getgenv().original.breathMax)
        breath.Value = state and math.huge or getgenv().original.breathVal
    end,

    toggleInfStam = function(state)
        stam:SetAttribute("Max", state and math.huge or getgenv().original.stamMax)
        stam.Value = state and math.huge or getgenv().original.stamVal
        overdrive.Value = state and math.huge or getgenv().original.overdriveVal
    end,

    toggleInfBattery = function(state)
        local flashlight = char:FindFirstChild("Flashlight") or char:WaitForChild("Flashlight")
        local battery = flashlight:WaitForChild("Battery")
        local charges = flashlight:WaitForChild("Charges")
        if state then
            getgenv().original.batteryMax = battery:GetAttribute("Max")
            getgenv().original.batteryVal = battery.Value
            getgenv().original.chargesVal = charges.Value
            battery:SetAttribute("Max", math.huge)
            battery.Value = math.huge
            charges.Value = math.huge
        else
            battery:SetAttribute("Max", getgenv().original.batteryMax)
            battery.Value = getgenv().original.batteryVal
            charges.Value = getgenv().original.chargesVal
        end
    end,

    toggleFullBright = function(state)
        getgenv().loopfb = state
        local lighting = game:GetService("Lighting")
        if state then
            getgenv().fbthread = task.spawn(function()
                while getgenv().loopfb do
                    lighting.Brightness = 2
                    lighting.ClockTime = 14
                    lighting.FogEnd = 100000
                    lighting.GlobalShadows = false
                    lighting.OutdoorAmbient = Color3.new(1,1,1)
                    task.wait()
                end
            end)
        else
            if getgenv().fbthread then task.cancel(getgenv().fbthread) end
            lighting.GlobalShadows = true
        end
    end,

    disableTemperature = function()
        local gui = Player:WaitForChild("PlayerGui"):WaitForChild("StatusUI")
        if gui:FindFirstChild("FrozenFX") then
            gui.FrozenFX.ImageTransparency = 1
        end
        local frost = game.ReplicatedStorage:FindFirstChild("Remotes") and game.ReplicatedStorage.Remotes:FindFirstChild("Frostbite")
        if frost then frost.FireServer = function() end end
    end,

    cameraClassic = function()
        Player.CameraMode = Enum.CameraMode.Classic
    end
}
